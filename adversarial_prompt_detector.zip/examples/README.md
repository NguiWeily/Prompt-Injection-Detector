Example prompts and guidance. See curl_examples.sh
